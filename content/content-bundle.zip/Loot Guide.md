# Treasure Allowance Per Adventure

## Mundane Equipment and Treasure
Mundane equipment found during the adventure can be used and divided up as the characters decide at the end of the adventure. Treasure (including items that have a monetary value but are not equipment, such as art objects and gems) is awarded as the adventure directs. It can be spent during the adventure; any remaining treasure at the end of the adventure is converted to gold pieces and divided equally among the characters

| Tier | Adventure Level | Gold per PC |
| ---- | --------------- | ----------- |
| 1    | Levels 1-4      | 300gp       | 
| 2    | Levels 5-10     | 3,000gp     |
| 3    | Levels 11-16    | 30,000gp    |
| 4    | Levels 17-20    | 75,000gp    |

## Magic items 

Characters can use and keep any magic item they find that is specifically mentioned in the encounter in which it’s found (items that the adventure describes as being lent to the characters or destroyed can’t be kept). At the end of the adventure, each character can keep any of magic items found during the adventure.

| Adventure Tier | Maximum Rarity |
| -------------- | -------------- |
| 1              | Uncommon       |
| 2              | Rare           |
| 3              | Very Rare      |
| 4              | Legendary      |

# Loot Distribution


| Rarity    | Value    |
| --------- | -------- |
| Common    | 40gp     |
| Uncommon  | 300gp    |
| Rare      | 5,000gp  |
| Very Rare | 30,000gp |
| Legendary | 75,000gp |

